
class Constant {
  static final menuExemplo = 'Exemplos de Bolos';
  static final menuSobre = 'Sobre';
  static final menuEncomenda = 'Encomende Seu Bolo';
  static final menuAPI = 'Consumindo a API';
  static final String baseURL = "api.postmon.com.br";
  static final String cepEndPoint = "/v1/cep/";
}