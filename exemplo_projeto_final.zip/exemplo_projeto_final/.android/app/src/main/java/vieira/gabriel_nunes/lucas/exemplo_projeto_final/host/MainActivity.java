package vieira.gabriel_nunes.lucas.exemplo_projeto_final.host;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
